package com.qq.e.union.demo;

public class Constants {
  public static final String APPID = "1101152570";
  public static final String BannerPosID = "9079537218417626401";
  public static final String InterteristalPosID = "8575134060152130849";
  public static final String SplashPosID = "8863364436303842593";
  public static final String NativePosID = "5010320697302671";
  public static final String NativeVideoPosID = "5090421627704602";
  public static final String NativeExpressPosID = "7030020348049331";
  public static final String CONTENT_AD_POS_ID = "6030826684185381";

}
